RVsitebuilderCMS real-setup changelog

### [2.1.6](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.5...v2.1.6) (2022-01-07)


### :bug: Bug fixed

* remove vendor/bin before copy overwrite ([91be241](https://github.com/rvsitebuilder-service/real-setup/commit/91be24111c26bfc8c8d22b7c0b5cc340405e48c9))

### [2.1.5](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.4...v2.1.5) (2021-10-14)


### :bug: Bug fixed

* require pdo_mysql ([d366b3f](https://github.com/rvsitebuilder-service/real-setup/commit/d366b3ffd1e4ceca6999780ddd9957e0003a40d5))
* require pdo_mysql ([33dfcb4](https://github.com/rvsitebuilder-service/real-setup/commit/33dfcb450cbdc5ea01370f6d354a12401462e6f3))

### [2.1.4](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.3...v2.1.4) (2021-10-11)


### :bug: Bug fixed

* validate-extension ([e7b6796](https://github.com/rvsitebuilder-service/real-setup/commit/e7b6796337fa1dfbf02dd2d170e98ddf38f1bf02))

### [2.1.3](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.2...v2.1.3) (2021-09-10)


### :bug: Bug fixed

* baseapp no longer has rvsitebuilder.json ([f2f9f3d](https://github.com/rvsitebuilder-service/real-setup/commit/f2f9f3d4312df93bcc2e9eb27d93290523abbe88))

### [2.1.2](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.1...v2.1.2) (2021-09-10)


### :bug: Bug fixed

* edit variable ([2d3df00](https://github.com/rvsitebuilder-service/real-setup/commit/2d3df00ca99f008dcd48778550fb47d9d7585a15))

### [2.1.1](https://github.com/rvsitebuilder-service/real-setup/compare/v2.1.0...v2.1.1) (2021-09-10)


### :bug: Bug fixed

* curl getversion ([a2e03e1](https://github.com/rvsitebuilder-service/real-setup/commit/a2e03e1843c7953282ce7f3581c1a3688a657f18))

## [2.1.0](https://github.com/rvsitebuilder-service/real-setup/compare/v2.0.0...v2.1.0) (2021-09-06)


### :memo: Feature

* support for CMS7.4 ([91c3832](https://github.com/rvsitebuilder-service/real-setup/commit/91c38327a7f716a8abf993fabcdd618e8be6ef2a))

## [2.1.0-beta.1](https://github.com/rvsitebuilder-service/real-setup/compare/v2.0.0...v2.1.0-beta.1) (2021-09-06)


### :memo: Feature

* support for CMS7.4 ([91c3832](https://github.com/rvsitebuilder-service/real-setup/commit/91c38327a7f716a8abf993fabcdd618e8be6ef2a))

## [2.0.0](https://github.com/rvsitebuilder-service/real-setup/compare/v1.0.0...v2.0.0) (2021-08-26)


### :rocket: Breaking

* action release ([e05c26a](https://github.com/rvsitebuilder-service/real-setup/commit/e05c26af35ec20de67ee2fc51d2a763a176a9317))


### :memo: Feature

* add .gitattributes ([eac1bce](https://github.com/rvsitebuilder-service/real-setup/commit/eac1bce59650d3ad93e341dccc1f6d2ae562da77))

## [2.0.0-beta.2](https://github.com/rvsitebuilder-service/real-setup/compare/v2.0.0-beta.1...v2.0.0-beta.2) (2021-08-26)


### :memo: Feature

* add .gitattributes ([eac1bce](https://github.com/rvsitebuilder-service/real-setup/commit/eac1bce59650d3ad93e341dccc1f6d2ae562da77))


## [2.0.0-beta.1](https://github.com/rvsitebuilder-service/real-setup/compare/v1.0.0...v2.0.0-beta.1) (2021-07-28)


### :rocket: Breaking

* action release ([e05c26a](https://github.com/rvsitebuilder-service/real-setup/commit/e05c26af35ec20de67ee2fc51d2a763a176a9317))
